module CredentialsGenerator {
}