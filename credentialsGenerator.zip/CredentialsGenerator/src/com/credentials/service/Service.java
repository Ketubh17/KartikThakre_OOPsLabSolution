package com.credentials.service;
import com.credentials.model.Employee;
import java.util.Random;
public class Service
{
	
   
	private String generatePassword()
	{
		

	    String capital="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	    String lower ="abcdefghijklmnopqrstuvwxyz";
	    String number ="0123456789";
	    String special ="!@#$%^&()";
	    
	    String password="";
	    String pwd =capital+lower+number+special;
		Random rn= new Random();
	
		for (int i= 0;i <= 8;i++)
		{
//			
		      password = password +pwd.charAt(rn.nextInt(pwd.length()));
		}
		
		
	   return password;
		
	}
	private String generateEmailAddress(Employee emp,String department) 
	{
		return emp.getFirstname()+emp.getLastname()+"@"+department+".abc.com";
	}
	public void showCredentials(Employee emp,String Deparment) 
	{
		System.out.println("Dear "+emp.getFirstname()+ "Your generated credentials are as follows");
		System.out.println("Generated email address"+ this.generateEmailAddress(emp, Deparment));
		System.out.println("Password is:" + this.generatePassword());
	}
}
