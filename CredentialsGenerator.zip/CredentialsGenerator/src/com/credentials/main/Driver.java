package com.credentials.main;
import java.util.Scanner;

import com.credentials.model.Employee;
import com.credentials.service.Service;
public class Driver {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		 Service sc = new Service();
	
		 Scanner scan=new Scanner(System.in);
         System.out.println("Enter your First name");
         String Firstname =scan.nextLine();
         System.out.println("Enter your Lastname");
         String Lastname=scan.nextLine();
         Employee emp =new Employee(Firstname,Lastname); 
    	 showMenu();
     	 int option=scan.nextInt();
     	 scan.nextLine();
     
     	 
     	 switch(option)
     	 {
     	 case 1 : 
     		   sc.showCredentials(emp, "Technical");
     		   
     		 break;
     	 case 2:
     		 
     		sc.showCredentials(emp, "Admin");
     		 break;
     		 
     	 case 3: 
     		 
     		sc.showCredentials(emp, "HumanResources");
     		 break;
     	 case 4:
     		 
     		sc.showCredentials(emp, "Legal");
     		 break;
     	 case 5:
     		 System.out.println("Plase select correct department");
     		 break;
     	 }
     	 
     	 
	}
	public static void showMenu()
	 {
			System.out.println();
	   	System.out.println("Enter the deparment from following");
	   	System.out.println(" 1: Technical");
	   	System.out.println("2 :Admin");
	   	System.out.println("3: Human Resources");
	   	System.out.println("4 :Legal");
   
	 }
	
	 
}
